/* eslint-disable import/prefer-default-export */
export function getDataForColumnSummary() {
  return [
    {
      a: '11',
      b: '3',
      __children: [
        {
          a: '11',
          b: '33'
        },
        {
          a: '112',
          b: '36',
        },
        {
          a: '119',
          b: '37'
        }
      ]
    },
    {
      a: '2',
      b: '6',
      __children: [
        {
          a: '112',
          b: '363',
        },
        {
          a: '121',
          b: '3633'
        }
      ]
    },
    {
      a: '9',
      b: '7',
      __children: [
        {
          a: '911',
          b: '73',
          __children: []
        },
        {
          a: '92',
          b: '76',
        }
      ]
    }
  ];
}
